package dadosCidadao;

public class Dependente {
	
	String nome;
	String sexo;
	double valorDep = 189.59;
	
	public double getValor() {
		return valorDep;
	}
	
	

}
