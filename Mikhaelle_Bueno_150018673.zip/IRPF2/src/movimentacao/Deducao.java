package movimentacao;

public class Deducao {
	public String descricao;
	 public double valor;
	 
	 public Deducao (String d, double v) {
		 descricao = d;
		 valor = v;
	 }
}
