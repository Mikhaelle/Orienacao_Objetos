package movimentacao;


public class Rendimento {
	 public String descricao;
	 public double valor;
	

	public Rendimento(String d, double v) {
		descricao = d;
		valor = v;
	}
}
